namespace UnityEngine.InputSystem.Steam
{
/*
    TODO
    public enum SteamControllerType
    {
        Unknown,
        SteamController,
        Xbox360,
        XboxOne,
        GenericXInput,
        PS4
    }
    */
}
